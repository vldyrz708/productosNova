// Configuración de la API
const API_URL = 'http://localhost:3000/api/albums';
